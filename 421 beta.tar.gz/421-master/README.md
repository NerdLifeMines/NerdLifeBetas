# 421 Official Development Repository

sha256
 
cryptocurrency
pos eligible after 10 days

port 8422
rpcport 8421 
