<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../forms/aboutdialog.ui" line="14"/>
        <source>About 421</source>
        <translation>Su 421</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="75"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;421&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;421&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="113"/>
        <source>Copyright © 2014 421 Developers</source>
        <translation>Copyright © 2014 Sviluppatori 421</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="120"/>
        <source>Copyright © 2011-2014 421 Developers</source>
        <translation>Copyright © 2011-2014 Sviluppatori 421 </translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="133"/>
        <source>Copyright © 2009-2014 Bitcoin Developers

This is experimental software.

Distributed under the MIT/X11 software license, see the accompanying file license.txt or http://www.opensource.org/licenses/mit-license.php.

This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit (http://www.openssl.org/) and cryptographic software written by Eric Young (eay@cryptsoft.com) and UPnP software written by Thomas Bernard.</source>
        <translation>Copyright © 2009-2014 Bitcoin Developers
Questo è un software sperimentale.
Distribuito secondo la licenza software MIT/X11, leggi il file di accompagnamento license.txt o http://www.opensource.org/licenses/mit-license.php.
Questo prodotto include software sviluppato dal progetto OpenSSL per l&apos;utilizzo nel Toolkit OpenSSL (http://www.openssl.org/)  e software crittografico scritto da Eric Young (eay@cryptsoft.com) e software UPnP scritto da by Thomas Bernard.</translation>
    </message>
</context>
<context>
    <name>AddressBookPage</name>
    <message>
        <location filename="../forms/addressbookpage.ui" line="14"/>
        <source>Address Book</source>
        <translation>Rubrica</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="20"/>
        <source>These are your 421 addresses for receiving payments.  You may want to give a different one to each sender so you can keep track of who is paying you.</source>
        <translation>Questi sono i tuoi indirizzi 421 per la ricezione di pagamenti. Potresti dare un indirizzo differente ad ogni mittente per tenere traccia di chi ti sta pagando.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="33"/>
        <source>Double-click to edit address or label</source>
        <translation>Fai doppio click per modificare o cancellare l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="57"/>
        <source>Create a new address</source>
        <translation>Crea un nuovo indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="60"/>
        <source>&amp;New Address...</source>
        <translation>&amp;Nuovo indirizzo...</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="71"/>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copia l&apos;indirizzo attualmente selezionato nella clipboard</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="74"/>
        <source>&amp;Copy to Clipboard</source>
        <translation>&amp;Copia nella clipboard</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="85"/>
        <source>Show &amp;QR Code</source>
        <translation>Mostra il codice &amp;QR</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="96"/>
        <source>Sign a message to prove you own this address</source>
        <translation>Firma un messaggio per dimostrare di possedere questo indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="99"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firma il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="110"/>
        <source>Delete the currently selected address from the list. Only sending addresses can be deleted.</source>
        <translation>Cancella l&apos;indirizzo attualmente selezionato dalla lista. Solo indirizzi d&apos;invio possono essere cancellati.</translation>
    </message>
    <message>
        <location filename="../forms/addressbookpage.ui" line="113"/>
        <source>&amp;Delete</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="65"/>
        <source>Copy address</source>
        <translation>Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="66"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="67"/>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="68"/>
        <source>Delete</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="273"/>
        <source>Export Address Book Data</source>
        <translation>Esporta gli indirizzi della rubrica</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="274"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="287"/>
        <source>Error exporting</source>
        <translation>Errore nell&apos;esportazione</translation>
    </message>
    <message>
        <location filename="../addressbookpage.cpp" line="287"/>
        <source>Could not write to file %1.</source>
        <translation>Impossibile scrivere sul file %1.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <location filename="../addresstablemodel.cpp" line="79"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="79"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../addresstablemodel.cpp" line="115"/>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="94"/>
        <source>TextLabel</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="47"/>
        <source>Enter passphrase</source>
        <translation>Inserisci la passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="61"/>
        <source>New passphrase</source>
        <translation>Nuova passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="75"/>
        <source>Repeat new passphrase</source>
        <translation>Ripeti la passphrase</translation>
    </message>
    <message>
        <location filename="../forms/askpassphrasedialog.ui" line="114"/>
        <source>Toggle Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="37"/>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;10 or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Inserisci la passphrase per il portafoglio.&lt;br/&gt;Per piacere usa una passphrase di &lt;b&gt;10 o più caratteri casuali&lt;/b&gt;, o &lt;b&gt;otto o più parole&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="38"/>
        <source>Encrypt wallet</source>
        <translation>Cifra il portafogli</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="41"/>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Quest&apos;operazione necessita della passphrase per sbloccare il portafogli.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="46"/>
        <source>Unlock wallet</source>
        <translation>Sblocca il portafoglio</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="49"/>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Quest&apos;operazione necessita della passphrase per decifrare il portafoglio.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="54"/>
        <source>Decrypt wallet</source>
        <translation>Decifra il portafoglio</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="57"/>
        <source>Change passphrase</source>
        <translation>Cambia la passphrase</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="58"/>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Inserisci la vecchia e la nuova passphrase per il portafoglio.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="106"/>
        <source>Confirm wallet encryption</source>
        <translation>Conferma la cifratura del portafoglio</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="116"/>
        <location filename="../askpassphrasedialog.cpp" line="165"/>
        <source>Wallet encrypted</source>
        <translation>Portafoglio cifrato</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="213"/>
        <location filename="../askpassphrasedialog.cpp" line="237"/>
        <source>Warning: The Caps Lock key is on.</source>
        <translation>Attenzione: tasto Blocco maiuscole attivo.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="122"/>
        <location filename="../askpassphrasedialog.cpp" line="129"/>
        <location filename="../askpassphrasedialog.cpp" line="171"/>
        <location filename="../askpassphrasedialog.cpp" line="177"/>
        <source>Wallet encryption failed</source>
        <translation>Cifratura del portafoglio fallita</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="107"/>
        <source>WARNING: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR PEERCOINS&lt;/b&gt;!
Are you sure you wish to encrypt your wallet?</source>
        <translation>ATTENZIONE: Se cifri il tuo portafoglio e perdi la tua parola chiave, &lt;b&gt;PERDERAI TUTTI I TUOI PEERCOINS&lt;/b&gt;!
Sei sicuro che vuoi cifrare il tuo portafoglio?</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="117"/>
        <source>421 will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your 421s from being stolen by malware infecting your computer.</source>
        <translation>421 si chiuderà adesso per finire il processo di criptazione. Ricorda che criptare il tuo portafoglio non può proteggere completamente i tuoi 421 da essere rubati con malware che ha infettato il tuo computer.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="123"/>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Cifratura del portafoglio fallita a causa di un errore interno. Il portafoglio non è stato cifrato.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="130"/>
        <location filename="../askpassphrasedialog.cpp" line="178"/>
        <source>The supplied passphrases do not match.</source>
        <translation>Le passphrase inserite non corrispondono.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="141"/>
        <source>Wallet unlock failed</source>
        <translation>Sblocco del portafoglio fallito</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="142"/>
        <location filename="../askpassphrasedialog.cpp" line="153"/>
        <location filename="../askpassphrasedialog.cpp" line="172"/>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La passphrase inserita per la decifrazione del portafoglio è errata.</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="152"/>
        <source>Wallet decryption failed</source>
        <translation>Decifrazione del portafoglio fallita</translation>
    </message>
    <message>
        <location filename="../askpassphrasedialog.cpp" line="166"/>
        <source>Wallet passphrase was succesfully changed.</source>
        <translation>Parola chiave del portafoglio modificata con successo.</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <location filename="../bitcoingui.cpp" line="191"/>
        <source>&amp;Overview</source>
        <translation>&amp;Sintesi</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="192"/>
        <source>Show general overview of wallet</source>
        <translation>Mostra lo stato generale del portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="197"/>
        <source>&amp;Transactions</source>
        <translation>&amp;Transazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="198"/>
        <source>Browse transaction history</source>
        <translation>Cerca nelle transazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="203"/>
        <source>&amp;Minting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="204"/>
        <source>Show your minting capacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="209"/>
        <source>&amp;Address Book</source>
        <translation>&amp;Rubrica</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="210"/>
        <source>Edit the list of stored addresses and labels</source>
        <translation>Modifica la lista degli indirizzi salvati e delle etichette</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="215"/>
        <source>&amp;Receive coins</source>
        <translation>&amp;Ricevi monete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="216"/>
        <source>Show the list of addresses for receiving payments</source>
        <translation>Mostra la lista di indirizzi su cui ricevere pagamenti</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="221"/>
        <source>&amp;Send coins</source>
        <translation>&amp;Invia monete</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="227"/>
        <source>Sign/Verify &amp;message</source>
        <translation>Firma/Verifica messaggio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="228"/>
        <source>Prove you control an address</source>
        <translation>Dimostra di controllare un indirizzo</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="249"/>
        <source>E&amp;xit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="250"/>
        <source>Quit application</source>
        <translation>Chiudi applicazione</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="254"/>
        <source>Show information about 421</source>
        <translation>Mostra informazioni su 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="256"/>
        <source>About &amp;Qt</source>
        <translation>Informazioni su &amp;Qt</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="257"/>
        <source>Show information about Qt</source>
        <translation>Mostra informazioni su Qt</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="259"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opzioni...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="264"/>
        <source>&amp;Export...</source>
        <translation>&amp;Esporta...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="265"/>
        <source>Export the data in the current tab to a file</source>
        <translation>Esporta i dati della tab corrente in un file</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="266"/>
        <source>&amp;Encrypt Wallet</source>
        <translation>&amp;Cifra il portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="267"/>
        <source>Encrypt or decrypt wallet</source>
        <translation>Cifra o decifra il portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="269"/>
        <source>&amp;Unlock Wallet for Minting Only</source>
        <translation>Sblocca il portafoglio solo per Coniare</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="270"/>
        <source>Unlock wallet only for minting. Sending coins will still require the passphrase.</source>
        <translation>Sblocca il portafoglio solo per coniare. Per inviare le monete bisogna avere la parola chiave.</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="272"/>
        <source>&amp;Backup Wallet</source>
        <translation>Backup del Portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="273"/>
        <source>Backup wallet to another location</source>
        <translation>Backup del portafoglio in un altra destinazione</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="274"/>
        <source>&amp;Change Passphrase</source>
        <translation>&amp;Cambia la passphrase</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="275"/>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambia la passphrase per la cifratura del portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="276"/>
        <source>&amp;Debug window</source>
        <translation>Finestra di debug</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="277"/>
        <source>Open debugging and diagnostic console</source>
        <translation>Apri console di debug e diagnostica</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="301"/>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="310"/>
        <source>&amp;Settings</source>
        <translation>&amp;Impostazioni</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="317"/>
        <source>&amp;Help</source>
        <translation>&amp;Aiuto</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="326"/>
        <source>Tabs toolbar</source>
        <translation>Barra degli strumenti &quot;Tabs&quot;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="338"/>
        <source>Actions toolbar</source>
        <translation>Barra degli strumenti &quot;Azioni&quot;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="350"/>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="658"/>
        <source>This transaction is over the size limit. You can still send it for a fee of %1. Do you want to pay the fee?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="76"/>
        <source>421 Wallet</source>
        <translation>Portafoglio 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="222"/>
        <source>Send coins to a 421 address</source>
        <translation>Invia monete ad un indirizzo 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="253"/>
        <source>&amp;About 421</source>
        <translation>Su 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="260"/>
        <source>Modify configuration options for 421</source>
        <translation>Modifica opzioni di configurazione per 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="262"/>
        <source>Show/Hide &amp;421</source>
        <translation>Mostra/Nascondi 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="263"/>
        <source>Show or hide the 421 window</source>
        <translation>Mostra o nascondi la finestra di 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="415"/>
        <source>421 client</source>
        <translation>Client 421</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="443"/>
        <source>p-qt</source>
        <translation>p-qt</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="507"/>
        <source>%n active connection(s) to 421 network</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="531"/>
        <source>Synchronizing with network...</source>
        <translation>Sto sincronizzando con la rete...</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="533"/>
        <source>~%n block(s) remaining</source>
        <translation type="unfinished">
            <numerusform>~%n bloccho rimanente</numerusform>
            <numerusform>~%n blocchi rimanenti</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="544"/>
        <source>Downloaded %1 of %2 blocks of transaction history (%3% done).</source>
        <translation>Scaricati %1 di %2 blocchi nella cronologia transazioni (%3% completato).</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="556"/>
        <source>Downloaded %1 blocks of transaction history.</source>
        <translation>Scaricati %1 blocchi dello storico transazioni.</translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="571"/>
        <source>%n second(s) ago</source>
        <translation type="unfinished">
            <numerusform>%n secondo fa</numerusform>
            <numerusform>%n secondi fa</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="575"/>
        <source>%n minute(s) ago</source>
        <translation type="unfinished">
            <numerusform>%n minuto fa</numerusform>
            <numerusform>%n minuti fa</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="579"/>
        <source>%n hour(s) ago</source>
        <translation type="unfinished">
            <numerusform>%n ora fa</numerusform>
            <numerusform>%n ore fa</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../bitcoingui.cpp" line="583"/>
        <source>%n day(s) ago</source>
        <translation type="unfinished">
            <numerusform>%n giorno fa</numerusform>
            <numerusform>%n giorni fa</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="589"/>
        <source>Up to date</source>
        <translation>Aggiornato</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="594"/>
        <source>Catching up...</source>
        <translation>In aggiornamento...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="602"/>
        <source>Last received block was generated %1.</source>
        <translation>L&apos;ultimo blocco ricevuto è stato generato %1</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="661"/>
        <source>Sending...</source>
        <translation>Invio...</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="688"/>
        <source>Sent transaction</source>
        <translation>Transazione inviata</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="689"/>
        <source>Incoming transaction</source>
        <translation>Transazione ricevuta</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="690"/>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Data: %1
Quantità: %2
Tipo: %3
Indirizzo: %4

</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="821"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked for block minting only&lt;/b&gt;</source>
        <translation>Il portamonete è &lt;b&gt;cifrato&lt;/b&gt; e attualmente &lt;b&gt;sbloccato solo per coniazione del blocco&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="821"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Il portafoglio è &lt;b&gt;cifrato&lt;/b&gt; e attualmente &lt;b&gt;sbloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="831"/>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Il portafoglio è &lt;b&gt;cifrato&lt;/b&gt; e attualmente &lt;b&gt;bloccato&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="888"/>
        <source>Backup Wallet</source>
        <translation>Backup del Portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="888"/>
        <source>Wallet Data (*.dat)</source>
        <translation>Dati del Portafoglio (*.dat)</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="891"/>
        <source>Backup Failed</source>
        <translation>Backup Fallito</translation>
    </message>
    <message>
        <location filename="../bitcoingui.cpp" line="891"/>
        <source>There was an error trying to save the wallet data to the new location.</source>
        <translation>C&apos;è stato un errore durante il salvataggio dei dati del portafoglio nella nuova destinazione</translation>
    </message>
    <message>
        <location filename="../bitcoin.cpp" line="128"/>
        <source>A fatal error occured. 421 can no longer continue safely and will quit.</source>
        <translation>Un errore fatale è occorso. 421 non può più continuare in modo sicuro e sarà terminato.</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="14"/>
        <source>Coin Control</source>
        <translation>Controllo Moneta</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="45"/>
        <source>Quantity:</source>
        <translation>Quantità:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="64"/>
        <location filename="../forms/coincontroldialog.ui" line="96"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="77"/>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="125"/>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="144"/>
        <location filename="../forms/coincontroldialog.ui" line="224"/>
        <location filename="../forms/coincontroldialog.ui" line="310"/>
        <location filename="../forms/coincontroldialog.ui" line="348"/>
        <source>0.00 BTC</source>
        <translation>123,456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="157"/>
        <source>Priority:</source>
        <translation>Priorità:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="205"/>
        <source>Fee:</source>
        <translation>Tariffa:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="240"/>
        <source>Low Output:</source>
        <translation>Output Basso:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="262"/>
        <location filename="../coincontroldialog.cpp" line="572"/>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="291"/>
        <source>After Fee:</source>
        <translation>Con Tariffa:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="326"/>
        <source>Change:</source>
        <translation>Cambio:</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="395"/>
        <source>(un)select all</source>
        <translation>(de)seleziona tutto</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="408"/>
        <source>Tree mode</source>
        <translation>Modalità ad albero</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="424"/>
        <source>List mode</source>
        <translation>Modalità lista </translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="469"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="479"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="484"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="489"/>
        <source>Confirmations</source>
        <translation>Conferme</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="492"/>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="497"/>
        <source>Coin days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/coincontroldialog.ui" line="502"/>
        <source>Priority</source>
        <translation>Priorità</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="36"/>
        <source>Copy address</source>
        <translation>Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="37"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="38"/>
        <location filename="../coincontroldialog.cpp" line="64"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="39"/>
        <source>Copy transaction ID</source>
        <translation>Copia ID della transazione</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="63"/>
        <source>Copy quantity</source>
        <translation>Copia quantità</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="65"/>
        <source>Copy fee</source>
        <translation>Copia tariffa</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="66"/>
        <source>Copy after fee</source>
        <translation>Copia dopo tariffa</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="67"/>
        <source>Copy bytes</source>
        <translation>Copia bytes</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="68"/>
        <source>Copy priority</source>
        <translation>Copia priorità</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="69"/>
        <source>Copy low output</source>
        <translation>Copia output basso</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="70"/>
        <source>Copy change</source>
        <translation>Copia cambiamento</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="388"/>
        <source>highest</source>
        <translation>più alto</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="389"/>
        <source>high</source>
        <translation>alto</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="390"/>
        <source>medium-high</source>
        <translation>medio-alto</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="391"/>
        <source>medium</source>
        <translation>medio</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="395"/>
        <source>low-medium</source>
        <translation>basso-medio</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="396"/>
        <source>low</source>
        <translation>basso</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="397"/>
        <source>lowest</source>
        <translation>bassissimo</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="572"/>
        <source>DUST</source>
        <translation>DUST</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="572"/>
        <source>yes</source>
        <translation>si</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="582"/>
        <source>This label turns red, if the transaction size is bigger than 10000 bytes.

 This means a fee of at least %1 per kb is required.

 Can vary +/- 1 Byte per input.</source>
        <translation>Questa etichetta diventa rossa, se la dimensione della transazione è maggiore di 10000 bytes.
Questo significa che  è richiesta una tariffa di almeno %1 per kb.
Può variare di +/- 1 Byyte per input.</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="583"/>
        <source>Transactions with higher priority get more likely into a block.

This label turns red, if the priority is smaller than &quot;medium&quot;.

 This means a fee of at least %1 per kb is required.</source>
        <translation>Le transazioni con più alta priorità entrano con maggiore possibilità in un blocco.
Questa etichetta diventa rossa, se la priorità è minore di &quot;media&quot;.
Questo significa che è necessaria una tariffa di almeno %1 per kb </translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="584"/>
        <source>This label turns red, if any recipient receives an amount smaller than %1.

 This means a fee of at least %2 is required. 

 Amounts below 0.546 times the minimum relay fee are shown as DUST.</source>
        <translation>Questa etichetta diventa rossa, se qualsiasi ricevente riceve un ammontare inferiore a %1.
Questo significa che è necessaria una tariffa di almeno %2.  
Ammontare al di sotto di 0.546 volte la tariffia minima di relay sono mostrate come DUST. </translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="585"/>
        <source>This label turns red, if the change is smaller than %1.

 This means a fee of at least %2 is required.</source>
        <translation>Questa etichetta diventa rossa, se il cambiamento è inferiore a %1.
Questo significa che è necessaria una tariffa di almeno %2.</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="622"/>
        <location filename="../coincontroldialog.cpp" line="688"/>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="679"/>
        <source>change from %1 (%2)</source>
        <translation>cambia da %1 (%2)</translation>
    </message>
    <message>
        <location filename="../coincontroldialog.cpp" line="680"/>
        <source>(change)</source>
        <translation>(cambia)</translation>
    </message>
</context>
<context>
    <name>DisplayOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="275"/>
        <source>&amp;Unit to show amounts in: </source>
        <translation>&amp;Unità di misura degli importi in: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="279"/>
        <source>Choose the default subdivision unit to show in the interface, and when sending coins</source>
        <translation>Scegli l&apos;unità di suddivisione di default per l&apos;interfaccia e per l&apos;invio di monete</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="286"/>
        <source>&amp;Display addresses in transaction list</source>
        <translation>Mostra indirizzi nella lista transazioni</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="287"/>
        <source>Whether to show 421 addresses in the transaction list</source>
        <translation>Se mostrare gli indirizzi 421 nella lista transazioni</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="290"/>
        <source>Display coin control features (experts only!)</source>
        <translation>Mostra funzionalità controllo moneta (solo esperti!)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="291"/>
        <source>Whether to show coin control features or not</source>
        <translation>Se mostrare funzionalità controllo moneta o no</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="14"/>
        <source>Edit Address</source>
        <translation>Modifica l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="25"/>
        <source>&amp;Label</source>
        <translation>&amp;Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="35"/>
        <source>The label associated with this address book entry</source>
        <translation>L&apos;etichetta associata a questo indirizzo nella rubrica</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="42"/>
        <source>&amp;Address</source>
        <translation>&amp;Indirizzo</translation>
    </message>
    <message>
        <location filename="../forms/editaddressdialog.ui" line="52"/>
        <source>The address associated with this address book entry. This can only be modified for sending addresses.</source>
        <translation>L&apos;indirizzo associato a questa voce della rubrica. Si può modificare solo negli indirizzi di invio.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="20"/>
        <source>New receiving address</source>
        <translation>Nuovo indirizzo di ricezione</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="24"/>
        <source>New sending address</source>
        <translation>Nuovo indirizzo d&apos;invio</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="27"/>
        <source>Edit receiving address</source>
        <translation>Modifica indirizzo di ricezione</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="31"/>
        <source>Edit sending address</source>
        <translation>Modifica indirizzo d&apos;invio</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="91"/>
        <source>The entered address &quot;%1&quot; is already in the address book.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; è già in rubrica.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="96"/>
        <source>The entered address &quot;%1&quot; is not a valid 421 address.</source>
        <translation>L&apos;indirizzo inserito &quot;%1&quot; non è un indirizzo 421 valido.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="101"/>
        <source>Could not unlock wallet.</source>
        <translation>Impossibile sbloccare il portafoglio.</translation>
    </message>
    <message>
        <location filename="../editaddressdialog.cpp" line="106"/>
        <source>New key generation failed.</source>
        <translation>Generazione della nuova chiave non riuscita.</translation>
    </message>
</context>
<context>
    <name>MainOptionsPage</name>
    <message>
        <location filename="../optionsdialog.cpp" line="177"/>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimizza sul tray invece che sulla barra delle applicazioni</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="178"/>
        <source>Show only a tray icon after minimizing the window</source>
        <translation>Mostra solo un&apos;icona nel tray quando si minimizza la finestra</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="186"/>
        <source>Map port using &amp;UPnP</source>
        <translation>Mappa le porte tramite l&apos;&amp;UPnP</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="181"/>
        <source>M&amp;inimize on close</source>
        <translation>M&amp;inimizza alla chiusura</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="182"/>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Riduci ad icona, invece di uscire dall&apos;applicazione quando la finestra viene chiusa. Quando questa opzione è attivata, l&apos;applicazione verrà chiusa solo dopo aver selezionato Esci nel menu.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="187"/>
        <source>Automatically open the 421 client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Aprire automaticamente la porta del client 421 nel router. Questo funziona solamente quando il supporto UPnp del router è abilitato.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="190"/>
        <source>&amp;Connect through SOCKS4 proxy:</source>
        <translation>&amp;Collegati tramite SOCKS4 proxy:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="191"/>
        <source>Connect to the Bitcon network through a SOCKS4 proxy (e.g. when connecting through Tor)</source>
        <translation>Connettiti alla rete Bitcon attraverso un proxy SOCKS4 (ad esempio quando ci si collega via Tor)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="196"/>
        <source>Proxy &amp;IP: </source>
        <translation>&amp;IP del proxy: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="202"/>
        <source>IP address of the proxy (e.g. 127.0.0.1)</source>
        <translation>Indirizzo IP del proxy (ad esempio 127.0.0.1)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="205"/>
        <source>&amp;Port: </source>
        <translation>&amp;Porta: </translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="211"/>
        <source>Port of the proxy (e.g. 1234)</source>
        <translation>Porta del proxy (es. 1234)</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="217"/>
        <source>Mandatory network transaction fee per kB transferred. Most transactions are 1 kB and incur a 0.01 421 fee. Note: transfer size may increase depending on the number of input transactions required to be added together to fund the payment.</source>
        <translation>Tariffa di transazione della rete obbligatoria per kB trasferito. La maggior parte delle transazioni sono 1kB ed hanno una tariffa di 0.01 421. Nota: la dimensione del trasferimento aumenta a seconda del numero delle transazioni di input totali necessarie per finanziare il pagamento.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="223"/>
        <source>Additional network &amp;fee:</source>
        <translation>Tariffa addizionale della rete:</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="234"/>
        <source>Detach databases at shutdown</source>
        <translation>Disconnetti i databases allo spegnimento</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="235"/>
        <source>Detach block and address databases at shutdown. This means they can be moved to another data directory, but it slows down shutdown. The wallet is always detached.</source>
        <translation>Disconnetti blocco e database indirizzi allo spegnimento. Questo significa che possono essere mossi in un altra directory dati, ma rallenta lo spegnimento. Il portafoglio è sempre disconnesso.</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="172"/>
        <source>&amp;Start 421 on window system startup</source>
        <translation>Avvia 421 a finestra all&apos;avvio del sistema</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="173"/>
        <source>Automatically start 421 after the computer is turned on</source>
        <translation>Automaticamente avvia 421 dopo che il computer è stato acceso</translation>
    </message>
</context>
<context>
    <name>MintingTableModel</name>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>Transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>Age</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>CoinDay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="203"/>
        <source>MintProbability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="284"/>
        <source>minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="291"/>
        <source>hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="295"/>
        <source>days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="298"/>
        <source>You have %1 chance to find a POS block if you mint %2 %3 at current difficulty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="418"/>
        <source>Destination address of the output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="420"/>
        <source>Original transaction id.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="422"/>
        <source>Age of the transaction in days.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="424"/>
        <source>Balance of the output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="426"/>
        <source>Coin age in the output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingtablemodel.cpp" line="428"/>
        <source>Chance to mint a block within given time interval.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MintingView</name>
    <message>
        <location filename="../mintingview.cpp" line="33"/>
        <source>transaction is too young</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="40"/>
        <source>transaction is mature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="47"/>
        <source>transaction  has reached maximum probability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="60"/>
        <source>Display minting probability within : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="62"/>
        <source>10 min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="63"/>
        <source>24 hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="64"/>
        <source>30 days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="65"/>
        <source>90 days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="162"/>
        <source>Export Minting Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="163"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="171"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="172"/>
        <source>Transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="173"/>
        <source>Age</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="174"/>
        <source>CoinDay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="175"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="176"/>
        <source>MintingProbability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="180"/>
        <source>Error exporting</source>
        <translation>Errore nell&apos;esportazione</translation>
    </message>
    <message>
        <location filename="../mintingview.cpp" line="180"/>
        <source>Could not write to file %1.</source>
        <translation>Impossibile scrivere sul file %1.</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../optionsdialog.cpp" line="81"/>
        <source>Main</source>
        <translation>Principale</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="86"/>
        <source>Display</source>
        <translation>Mostra</translation>
    </message>
    <message>
        <location filename="../optionsdialog.cpp" line="106"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <location filename="../forms/overviewpage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="40"/>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="54"/>
        <source>Number of transactions:</source>
        <translation>Numero di transazioni:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="61"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="68"/>
        <source>Unconfirmed:</source>
        <translation>Non confermato:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="82"/>
        <source>Stake:</source>
        <translation>Stake:</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="102"/>
        <source>Wallet</source>
        <translation>Portafoglio</translation>
    </message>
    <message>
        <location filename="../forms/overviewpage.ui" line="138"/>
        <source>&lt;b&gt;Recent transactions&lt;/b&gt;</source>
        <translation>&lt;b&gt;Transazioni recenti&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="104"/>
        <source>Your current balance</source>
        <translation>Saldo attuale</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="109"/>
        <source>Your current stake</source>
        <translation>Il tuo stake corrente</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="114"/>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the current balance</source>
        <translation>Totale delle transazioni in corso di conferma, che non sono ancora incluse nel saldo attuale</translation>
    </message>
    <message>
        <location filename="../overviewpage.cpp" line="117"/>
        <source>Total number of transactions in wallet</source>
        <translation>Numero delle transazioni effettuate nel portafoglio</translation>
    </message>
</context>
<context>
    <name>QRCodeDialog</name>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialogo</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="32"/>
        <source>QR Code</source>
        <translation>Codice QR</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="55"/>
        <source>Request Payment</source>
        <translation>Richiedi pagamento</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="70"/>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="105"/>
        <source>421</source>
        <translation>421</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="121"/>
        <source>Label:</source>
        <translation>Etichetta:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="144"/>
        <source>Message:</source>
        <translation>Messaggio:</translation>
    </message>
    <message>
        <location filename="../forms/qrcodedialog.ui" line="186"/>
        <source>&amp;Save As...</source>
        <translation>&amp;Salva come...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="46"/>
        <source>Error encoding URI into QR Code.</source>
        <translation>Errore codifica URI in Codice QR</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="64"/>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>URI risultante troppo lunga, prova ad accorciare il testo dell&apos;etichetta / messaggio.</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="121"/>
        <source>Save Image...</source>
        <translation>Salva Immagine...</translation>
    </message>
    <message>
        <location filename="../qrcodedialog.cpp" line="121"/>
        <source>PNG Images (*.png)</source>
        <translation>Immagini PNG (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <location filename="../forms/rpcconsole.ui" line="14"/>
        <source>421 (421) debug window</source>
        <translation>Finestra debug 421 (421)</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="24"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="33"/>
        <source>Client name</source>
        <translation>Nome Client</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="40"/>
        <location filename="../forms/rpcconsole.ui" line="60"/>
        <location filename="../forms/rpcconsole.ui" line="106"/>
        <location filename="../forms/rpcconsole.ui" line="156"/>
        <location filename="../forms/rpcconsole.ui" line="176"/>
        <location filename="../forms/rpcconsole.ui" line="196"/>
        <location filename="../forms/rpcconsole.ui" line="229"/>
        <location filename="../rpcconsole.cpp" line="338"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="53"/>
        <source>Client version</source>
        <translation>Versione Client</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="79"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="92"/>
        <source>Network</source>
        <translation>Rete</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="99"/>
        <source>Number of connections</source>
        <translation>Numero connessioni</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="119"/>
        <source>On testnet</source>
        <translation>Su testnet</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="142"/>
        <source>Block chain</source>
        <translation>Catena a blocchi</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="149"/>
        <source>Current number of blocks</source>
        <translation>Numero blocchi corrrente</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="169"/>
        <source>Estimated total blocks</source>
        <translation>Totale blocchi stimati</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="189"/>
        <source>Last block time</source>
        <translation>Tempo ultimo blocco</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="222"/>
        <source>Build date</source>
        <translation>Data Build</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="237"/>
        <source>Console</source>
        <translation>Console</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="270"/>
        <source>&gt;</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <location filename="../forms/rpcconsole.ui" line="286"/>
        <source>Clear console</source>
        <translation>Cancella console</translation>
    </message>
    <message>
        <location filename="../rpcconsole.cpp" line="306"/>
        <source>Welcome to the 421 RPC console.&lt;br&gt;Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.&lt;br&gt;Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Benvenuto alla console 421 RPC.&lt;br&gt;Utilizza le frecce in alto e in basso per navigare la cronologia, e &lt;b&gt;Ctrl-L&lt;/b&gt;per cancellare lo schermo.&lt;br&gt;Scrivi &lt;b&gt;aiuto&lt;/b&gt; per una panoramica dei comandi disponibili.</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="14"/>
        <location filename="../sendcoinsdialog.cpp" line="176"/>
        <location filename="../sendcoinsdialog.cpp" line="181"/>
        <location filename="../sendcoinsdialog.cpp" line="186"/>
        <location filename="../sendcoinsdialog.cpp" line="191"/>
        <location filename="../sendcoinsdialog.cpp" line="197"/>
        <location filename="../sendcoinsdialog.cpp" line="202"/>
        <location filename="../sendcoinsdialog.cpp" line="207"/>
        <source>Send Coins</source>
        <translation>Spedisci 421</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="90"/>
        <source>Coin Control Features</source>
        <translation>Funzionalità Controllo Moneta</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="110"/>
        <source>Inputs...</source>
        <translation>Inputs...</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="117"/>
        <source>automatically selected</source>
        <translation>automaticamente selezionato</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="136"/>
        <source>Insufficient funds!</source>
        <translation>Fondi Insufficienti!</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="213"/>
        <source>Quantity:</source>
        <translation>Quantità:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="235"/>
        <location filename="../forms/sendcoinsdialog.ui" line="270"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="251"/>
        <source>Bytes:</source>
        <translation>Bytes:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="302"/>
        <source>Amount:</source>
        <translation>Importo:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="324"/>
        <location filename="../forms/sendcoinsdialog.ui" line="410"/>
        <location filename="../forms/sendcoinsdialog.ui" line="496"/>
        <location filename="../forms/sendcoinsdialog.ui" line="528"/>
        <source>0.00 BTC</source>
        <translation>123,456 BTC {0.00 ?}</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="337"/>
        <source>Priority:</source>
        <translation>Priorità:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="356"/>
        <source>medium</source>
        <translation>medio</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="388"/>
        <source>Fee:</source>
        <translation>Tariffa:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="423"/>
        <source>Low Output:</source>
        <translation>Output Basso:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="442"/>
        <source>no</source>
        <translation>no</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="474"/>
        <source>After Fee:</source>
        <translation>Con Tariffa:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="509"/>
        <source>Change</source>
        <translation>Cambia</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="559"/>
        <source>custom change address</source>
        <translation>indirizzo scambio personalizzato</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="665"/>
        <source>Send to multiple recipients at once</source>
        <translation>Spedisci a diversi beneficiari in una volta sola</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="668"/>
        <source>&amp;Add recipient...</source>
        <translation>&amp;Aggiungi beneficiario...</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="685"/>
        <source>Remove all transaction fields</source>
        <translation>Rimuovi tutti i campi della transazione</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="688"/>
        <source>Clear all</source>
        <translation>Cancella tutto</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="707"/>
        <source>Balance:</source>
        <translation>Saldo:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="714"/>
        <source>123.456 BTC</source>
        <translation>123,456 BTC</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="745"/>
        <source>Confirm the send action</source>
        <translation>Conferma la spedizione</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsdialog.ui" line="748"/>
        <source>&amp;Send</source>
        <translation>&amp;Spedisci</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="51"/>
        <source>Copy quantity</source>
        <translation>Copia quantità</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="52"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="53"/>
        <source>Copy fee</source>
        <translation>Copia tariffa</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="54"/>
        <source>Copy after fee</source>
        <translation>Copia dopo tariffa</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="55"/>
        <source>Copy bytes</source>
        <translation>Copia bytes</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="56"/>
        <source>Copy priority</source>
        <translation>Copia priorità</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="57"/>
        <source>Copy low output</source>
        <translation>Copia output basso</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="58"/>
        <source>Copy change</source>
        <translation>Copia cambiamento</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="144"/>
        <source>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; to %2 (%3)</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="149"/>
        <source>Confirm send coins</source>
        <translation>Conferma la spedizione di 421</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="150"/>
        <source>Are you sure you want to send %1?</source>
        <translation>Si è sicuri di voler spedire %1?</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="150"/>
        <source> and </source>
        <translation> e </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="182"/>
        <source>The amount to pay must be at least one cent (0.01).</source>
        <translation>L&apos;ammmontare da pagare deve essere di almeno un centesimo (0.01).</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="457"/>
        <source>Warning: Invalid Bitcoin address</source>
        <translation>Attenzione: Indirizzo Bittcoin non vaildo</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="466"/>
        <source>Warning: Unknown change address</source>
        <translation>Attenzione: Cambio indirzzo sconosciuto</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="477"/>
        <source>(no label)</source>
        <translation>(nessuna etichetta)</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="187"/>
        <source>Amount exceeds your balance</source>
        <translation>L&apos;importo è superiore al saldo attuale</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="36"/>
        <source>Enter a 421 address</source>
        <translation>Inserisci un indirzzo 421</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="177"/>
        <source>The recipient address is not valid, please recheck.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="192"/>
        <source>Total exceeds your balance when the %1 transaction fee is included</source>
        <translation>Il totale è superiore al saldo attuale includendo la commissione %1</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="198"/>
        <source>Duplicate address found, can only send to each address once in one send operation</source>
        <translation>Trovato un indirizzo doppio, si può spedire solo una volta a ciascun indirizzo in una singola operazione.</translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="203"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Errore: creazione della transazione fallita </translation>
    </message>
    <message>
        <location filename="../sendcoinsdialog.cpp" line="208"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Errore: la transazione è stata rifiutata. Ciò accade se alcune monete nel portafoglio sono state già spese, ad esempio se è stata usata una copia del file wallet.dat e i peercoin sono stati spesi dalla copia ma non segnati come spesi qui.</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="29"/>
        <source>A&amp;mount:</source>
        <translation>&amp;Importo:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="42"/>
        <source>Pay &amp;To:</source>
        <translation>Paga &amp;a:</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="66"/>
        <location filename="../sendcoinsentry.cpp" line="26"/>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Inserisci un&apos;etichetta per questo indirizzo, per aggiungerlo nella rubrica</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="75"/>
        <source>&amp;Label:</source>
        <translation>&amp;Etichetta</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="93"/>
        <source>The address to send the payment to</source>
        <translation>L&apos;indirizzo a cui inviare il pagamento</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="103"/>
        <source>Choose address from address book</source>
        <translation>Scegli l&apos;indirizzo dalla rubrica</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="113"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="120"/>
        <source>Paste address from clipboard</source>
        <translation>Incollare l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="130"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/sendcoinsentry.ui" line="137"/>
        <source>Remove this recipient</source>
        <translation>Rimuovere questo beneficiario</translation>
    </message>
    <message>
        <location filename="../sendcoinsentry.cpp" line="25"/>
        <source>Enter a 421 address</source>
        <translation>Inserisci un indirzzo 421</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="14"/>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Firme - Firma / Verifica un Messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="24"/>
        <source>&amp;Sign Message</source>
        <translation>&amp;Firma il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="30"/>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Puoi firmare i messaggi con il tuo indirizzo per provare che sono di tua proprietà. Fai attenzione nel firmare nulla di vago, siccome attacchi di phishing possono spingerti a firmare la tua identità su di essi. Firma solo dettagliate affermazioni che accetti.</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="48"/>
        <source>The address to sign the message with</source>
        <translation>L&apos;indirizzo con cui firmare  il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="55"/>
        <location filename="../forms/signverifymessagedialog.ui" line="265"/>
        <source>Choose previously used address</source>
        <translation>Scegli un indirizzo utilizzato in precedenza</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="65"/>
        <location filename="../forms/signverifymessagedialog.ui" line="275"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="75"/>
        <source>Paste address from clipboard</source>
        <translation>Incollare l&apos;indirizzo dagli appunti</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="85"/>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="97"/>
        <source>Enter the message you want to sign here</source>
        <translation>Inserisci qui il messaggio che vuoi firmare</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="104"/>
        <source>Signature</source>
        <translation>Firma</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="131"/>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Compia la firma corrente nella clipboard del sistema</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="152"/>
        <source>Sign the message to prove you own this 421 address</source>
        <translation>Firma un messaggio per dimostrare di possedere questo indirizzo 421</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="155"/>
        <source>Sign &amp;Message</source>
        <translation>Firma il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="169"/>
        <source>Reset all sign message fields</source>
        <translation>Firma &amp;il messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="172"/>
        <location filename="../forms/signverifymessagedialog.ui" line="315"/>
        <source>Clear &amp;All</source>
        <translation>Cancella &amp;Tutto</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="231"/>
        <source>&amp;Verify Message</source>
        <translation>&amp;Verifica Messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="237"/>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Inserire l&apos;indirizzo per la firma, il messaggio (assicurati di copiare gli intervalli fra le linee, spazi, tabulatura, ecc.. in maniera esatta) e la firma qui sotto per verificare il messaggio. Fare attenzione a non leggere oltre quello che si trova nel messaggio firmato, per evitare di essere vittima di un attacco man-in-the-middle.</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="258"/>
        <source>The address the message was signed with</source>
        <translation>L&apos;indirizzo con il quale il messaggio è stato firmato</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="295"/>
        <source>Verify the message to ensure it was signed with the specified 421 address</source>
        <translation>Verifica il messaggio per assicurarsi che sia stato firmato con l&apos;indirzzo 421 specificato</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="298"/>
        <source>Verify &amp;Message</source>
        <translation>Verifica Messaggio</translation>
    </message>
    <message>
        <location filename="../forms/signverifymessagedialog.ui" line="312"/>
        <source>Reset all verify message fields</source>
        <translation>Resetta tutti i campi di verifica messaggio</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="29"/>
        <source>Click &quot;Sign Message&quot; to generate signature</source>
        <translation>Clicca &quot;Firma Messaggio&quot; per generare la firma</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="30"/>
        <source>Enter the signature of the message</source>
        <translation>Inserisci la firma del messaggio</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="31"/>
        <location filename="../signverifymessagedialog.cpp" line="32"/>
        <source>Enter a 421 address</source>
        <translation>Inserisci un indirzzo 421</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="115"/>
        <location filename="../signverifymessagedialog.cpp" line="195"/>
        <source>The entered address is invalid.</source>
        <translation>L&apos;indirzzo inserito non è valido.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="115"/>
        <location filename="../signverifymessagedialog.cpp" line="123"/>
        <location filename="../signverifymessagedialog.cpp" line="195"/>
        <location filename="../signverifymessagedialog.cpp" line="203"/>
        <source>Please check the address and try again.</source>
        <translation>Per favore controlla l&apos;indirizzo e prova di nuovo.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="123"/>
        <location filename="../signverifymessagedialog.cpp" line="203"/>
        <source>The entered address does not refer to a key.</source>
        <translation>L&apos;indirizzo digitato non corrisponde ad una chiave.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="131"/>
        <source>Wallet unlock was cancelled.</source>
        <translation>Sblocco del portafoglio cancellato.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="139"/>
        <source>Private key for the entered address is not available.</source>
        <translation>La chiave privata dell&apos;indirizzo immesso non è disponibile.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="151"/>
        <source>Message signing failed.</source>
        <translation>Firma del messaggio fallita.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="156"/>
        <source>Message signed.</source>
        <translation>Messaggio firmato.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="214"/>
        <source>The signature could not be decoded.</source>
        <translation>Non è stato possibile decodificare la firma.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="214"/>
        <location filename="../signverifymessagedialog.cpp" line="227"/>
        <source>Please check the signature and try again.</source>
        <translation>Per favore controlla la firma e prova di nuovo.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="227"/>
        <source>The signature did not match the message digest.</source>
        <translation>La firma non corrisponde al digest del messaggio.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="234"/>
        <source>Message verification failed.</source>
        <translation>Verifica del messaggio fallita.</translation>
    </message>
    <message>
        <location filename="../signverifymessagedialog.cpp" line="239"/>
        <source>Message verified.</source>
        <translation>Messaggio verificato.</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message>
        <location filename="../transactiondesc.cpp" line="21"/>
        <source>Open for %1 blocks</source>
        <translation>Aperto per %1 blocchi</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="23"/>
        <source>Open until %1</source>
        <translation>Aperto fino a %1</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="29"/>
        <source>%1/offline?</source>
        <translation>%1/offline?</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="31"/>
        <source>%1/unconfirmed</source>
        <translation>%1/non confermato</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="33"/>
        <source>%1 confirmations</source>
        <translation>%1 conferme</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="51"/>
        <source>&lt;b&gt;Status:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Stato:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="56"/>
        <source>, has not been successfully broadcast yet</source>
        <translation>, non è stato ancora trasmesso con successo</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="58"/>
        <source>, broadcast through %1 node</source>
        <translation>, trasmesso attraverso %1 nodo</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="60"/>
        <source>, broadcast through %1 nodes</source>
        <translation>, trasmesso attraverso %1 nodi</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="64"/>
        <source>&lt;b&gt;Date:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Data:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="71"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; Generated&lt;br&gt;</source>
        <translation>&lt;b&gt;Fonte:&lt;/b&gt; Generato&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="77"/>
        <location filename="../transactiondesc.cpp" line="94"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Da:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="94"/>
        <source>unknown</source>
        <translation>sconosciuto</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="95"/>
        <location filename="../transactiondesc.cpp" line="118"/>
        <location filename="../transactiondesc.cpp" line="178"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Per:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="98"/>
        <source> (yours, label: </source>
        <translation> (vostro, etichetta: </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="100"/>
        <source> (yours)</source>
        <translation> (vostro)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="136"/>
        <location filename="../transactiondesc.cpp" line="150"/>
        <location filename="../transactiondesc.cpp" line="195"/>
        <location filename="../transactiondesc.cpp" line="212"/>
        <source>&lt;b&gt;Credit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Credito:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="138"/>
        <source>(%1 matures in %2 more blocks)</source>
        <translation>(%1 matura in altri %2 blocchi)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="142"/>
        <source>(not accepted)</source>
        <translation>(non accettate)</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="186"/>
        <location filename="../transactiondesc.cpp" line="194"/>
        <location filename="../transactiondesc.cpp" line="209"/>
        <source>&lt;b&gt;Debit:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Debito:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="200"/>
        <source>&lt;b&gt;Transaction fee:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Commissione:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="218"/>
        <source>&lt;b&gt;Net amount:&lt;/b&gt; </source>
        <translation>&lt;b&gt;Importo netto:&lt;/b&gt; </translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="220"/>
        <source>&lt;b&gt;Retained amount:&lt;/b&gt; %1 until %2 more blocks&lt;br&gt;</source>
        <translation>&lt;b&gt;Totale ritenuto:&lt;/b&gt; %1 fino ad ancora %2 blocchi&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="227"/>
        <source>Message:</source>
        <translation>Messaggio:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="229"/>
        <source>Comment:</source>
        <translation>Commento:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="231"/>
        <source>Transaction ID:</source>
        <translation>ID della transazione:</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="234"/>
        <source>Generated coins must wait 520 blocks before they can be spent.  When you generated this block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be spendable.  This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Bisogna attendere 120 blocchi prima di spendere I 421 generati. Quando è stato generato questo blocco, è stato trasmesso alla rete per aggiungerlo alla catena di blocchi. Se non riesce a entrare nella catena, verrà modificato in &quot;non accettato&quot; e non sarà spendibile. Questo può accadere a volte, se un altro nodo genera un blocco entro pochi secondi del tuo. {520 ?}</translation>
    </message>
    <message>
        <location filename="../transactiondesc.cpp" line="236"/>
        <source>Staked coins must wait 520 blocks before they can return to balance and be spent.  When you generated this proof-of-stake block, it was broadcast to the network to be added to the block chain.  If it fails to get into the chain, it will change to &quot;not accepted&quot; and not be a valid stake.  This may occasionally happen if another node generates a proof-of-stake block within a few seconds of yours.</source>
        <translation>Le monete nello stake devono attendere 520 blocchi prima che possano ritornare nel bilancio ed essere spese. Quando hai generato questo blocco proof-of-stake, esso è stato diffuso nella rete per essere aggiunto nella catena a blocchi. Se fallisce l&apos;inserimento nella chiave a blocchi, esso cambierà a &quot;non accettato&quot; e non sarà uno stake valido. Questo potrebbe accadere occasionalmente se un altro nodo geera un blocco proof-of-stake entro pochi secondi dal tuo.</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="14"/>
        <source>Transaction details</source>
        <translation>Dettagli sulla transazione</translation>
    </message>
    <message>
        <location filename="../forms/transactiondescdialog.ui" line="20"/>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Questo pannello mostra una descrizione dettagliata della transazione</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <location filename="../transactiontablemodel.cpp" line="214"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="214"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="214"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="214"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="281"/>
        <source>Open for %n block(s)</source>
        <translation>
            <numerusform>Aperto per %n blocco</numerusform>
            <numerusform>Aperto per %n blocchi</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="284"/>
        <source>Open until %1</source>
        <translation>Aperto fino a %1</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="287"/>
        <source>Offline (%1 confirmations)</source>
        <translation>Offline (%1 conferme)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="290"/>
        <source>Unconfirmed (%1 of %2 confirmations)</source>
        <translation>Non confermati (%1 su %2 conferme)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="293"/>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confermato (%1 conferme)</translation>
    </message>
    <message numerus="yes">
        <location filename="../transactiontablemodel.cpp" line="301"/>
        <source>Mined balance will be available in %n more blocks</source>
        <translation>
            <numerusform>Il saldo generato sarà disponibile tra %n altro blocco</numerusform>
            <numerusform>Il saldo generato sarà disponibile tra %n altri blocchi</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="307"/>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Questo blocco non è stato ricevuto da altri nodi e probabilmente non sarà accettato!</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="310"/>
        <source>Generated but not accepted</source>
        <translation>Generati, ma non accettati</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="353"/>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="355"/>
        <source>Received from</source>
        <translation>Ricevuto da</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="358"/>
        <source>Sent to</source>
        <translation>Spedito a</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="360"/>
        <source>Payment to yourself</source>
        <translation>Pagamento a te stesso</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="362"/>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="364"/>
        <source>Mint by stake</source>
        <translation>Conia attraverso lo stake</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="403"/>
        <source>(n/a)</source>
        <translation>(N / a)</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="603"/>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Stato della transazione. Passare con il mouse su questo campo per vedere il numero di conferme.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="605"/>
        <source>Date and time that the transaction was received.</source>
        <translation>Data e ora in cui la transazione è stata ricevuta.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="607"/>
        <source>Type of transaction.</source>
        <translation>Tipo di transazione.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="609"/>
        <source>Destination address of transaction.</source>
        <translation>Indirizzo di destinazione della transazione.</translation>
    </message>
    <message>
        <location filename="../transactiontablemodel.cpp" line="611"/>
        <source>Amount removed from or added to balance.</source>
        <translation>Importo rimosso o aggiunto al saldo.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <location filename="../transactionview.cpp" line="55"/>
        <location filename="../transactionview.cpp" line="71"/>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="56"/>
        <source>Today</source>
        <translation>Oggi</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="57"/>
        <source>This week</source>
        <translation>Questa settimana</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="58"/>
        <source>This month</source>
        <translation>Questo mese</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="59"/>
        <source>Last month</source>
        <translation>Il mese scorso</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="60"/>
        <source>This year</source>
        <translation>Quest&apos;anno</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="61"/>
        <source>Range...</source>
        <translation>Intervallo...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="72"/>
        <source>Received with</source>
        <translation>Ricevuto tramite</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="74"/>
        <source>Sent to</source>
        <translation>Spedito a</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="76"/>
        <source>To yourself</source>
        <translation>A te</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="77"/>
        <source>Mined</source>
        <translation>Ottenuto dal mining</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="78"/>
        <source>Mint by stake</source>
        <translation>Conia attraverso lo stake</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="79"/>
        <source>Other</source>
        <translation>Altro</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="85"/>
        <source>Enter address or label to search</source>
        <translation>Inserisci un indirizzo o un&apos;etichetta da cercare</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="91"/>
        <source>Min amount</source>
        <translation>Importo minimo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="125"/>
        <source>Copy address</source>
        <translation>Copia l&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="126"/>
        <source>Copy label</source>
        <translation>Copia l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="127"/>
        <source>Copy amount</source>
        <translation>Copia l&apos;importo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="128"/>
        <source>Edit label</source>
        <translation>Modifica l&apos;etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="129"/>
        <source>Show details...</source>
        <translation>Mostra i dettagli...</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="130"/>
        <source>Clear orphans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="273"/>
        <source>Export Transaction Data</source>
        <translation>Esporta i dati della transazione</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="274"/>
        <source>Comma separated file (*.csv)</source>
        <translation>Testo CSV (*.csv)</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="282"/>
        <source>Confirmed</source>
        <translation>Confermato</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="283"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="284"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="285"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="286"/>
        <source>Address</source>
        <translation>Indirizzo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="287"/>
        <source>Amount</source>
        <translation>Importo</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="288"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="292"/>
        <source>Error exporting</source>
        <translation>Errore nell&apos;esportazione</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="292"/>
        <source>Could not write to file %1.</source>
        <translation>Impossibile scrivere sul file %1.</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="400"/>
        <source>Range:</source>
        <translation>Intervallo:</translation>
    </message>
    <message>
        <location filename="../transactionview.cpp" line="408"/>
        <source>to</source>
        <translation>a</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <location filename="../walletmodel.cpp" line="164"/>
        <source>Sending...</source>
        <translation>Invio...</translation>
    </message>
</context>
<context>
    <name>bitcoin-core</name>
    <message>
        <location filename="../bitcoinstrings.cpp" line="11"/>
        <source>Warning: Disk space is low  </source>
        <translation>Attenzione: lo spazio su disco è scarso </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="13"/>
        <source>Usage:</source>
        <translation>Utilizzo:</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="8"/>
        <source>Unable to bind to port %d on this computer.  421 is probably already running.</source>
        <translation>Impossibile connettersi con la porta %d su questo computer. 421 è probabilmente già in funzione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="12"/>
        <source>421 version</source>
        <translation>Versione 421</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="14"/>
        <source>Send command to -server or 421d</source>
        <translation>Invia un comando al -server o 421d</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="15"/>
        <source>List commands</source>
        <translation>Lista comandi
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="16"/>
        <source>Get help for a command</source>
        <translation>Aiuto su un comando
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="17"/>
        <source>Options:</source>
        <translation>Opzioni:
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="18"/>
        <source>Specify configuration file (default: 421.conf)</source>
        <translation>Specifia il file di configurazione (default: 421.conf)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="19"/>
        <source>Specify pid file (default: 421d.pid)</source>
        <translation>Specifica il file pid (default: 421d.pid)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="20"/>
        <source>Generate coins</source>
        <translation>Genera 421
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="21"/>
        <source>Don&apos;t generate coins</source>
        <translation>Non generare 421
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="22"/>
        <source>Start minimized</source>
        <translation>Parti in icona
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="23"/>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Mostra schermata di avvio durante il caricamento</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="24"/>
        <source>Specify data directory</source>
        <translation>Specifica la cartella dati
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="25"/>
        <source>Set database cache size in megabytes (default: 25)</source>
        <translation>Impostare dimensione cache del database in megabytes (default:25)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="26"/>
        <source>Set database disk log size in megabytes (default: 100)</source>
        <translation>Impostare dimensione log disco in megabytes (default:100)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="27"/>
        <source>Specify connection timeout (in milliseconds)</source>
        <translation>Specifica il timeout di connessione (in millisecondi)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="28"/>
        <source>Connect through socks4 proxy</source>
        <translation>Connessione tramite socks4 proxy
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="29"/>
        <source>Allow DNS lookups for addnode and connect</source>
        <translation>Consenti ricerche DNS per aggiungere nodi e collegare
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="30"/>
        <source>Listen for connections on &lt;port&gt; (default: 8422 or testnet: 9903)</source>
        <translation>Ascolta le connessioni JSON-RPC su &lt;porta&gt; (default: 8333 o testnet: 18333) {8422 ?} {9903)?}</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="31"/>
        <source>Maintain at most &lt;n&gt; connections to peers (default: 125)</source>
        <translation>Mantieni al massimo &lt;n&gt; connessioni ai peer (default: 125)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="32"/>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Aggiungi un nodo per connettersi e tentare di mantenere la aperta la connessione</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="33"/>
        <source>Connect only to the specified node</source>
        <translation>Connetti solo al nodo specificato
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="34"/>
        <source>Find peers using internet relay chat (default: 0)</source>
        <translation>Trova peers usando internet relay chat (default:0)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="35"/>
        <source>Accept connections from outside (default: 1)</source>
        <translation>Accetta connessioni dall&apos;esterno (default:1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="36"/>
        <source>Set language, for example &quot;de_DE&quot; (default: system locale)</source>
        <translation>Imposta linguaggio, ad esempio &quot;de_DE&quot; (default:system locale)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="37"/>
        <source>Find peers using DNS lookup (default: 1)</source>
        <translation>Trova peers usando lookup DNS (default:1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="38"/>
        <source>Threshold for disconnecting misbehaving peers (default: 100)</source>
        <translation>Soglia di disconnessione dei peer di cattiva qualità (default: 100)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="39"/>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: 86400)</source>
        <translation>Numero di secondi di sospensione che i peer di cattiva qualità devono attendere prima di riconnettersi (default: 86400)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="42"/>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Buffer di ricezione massimo per connessione, &lt;n&gt;*1000 byte (default: 10000)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="43"/>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: 10000)</source>
        <translation>Buffer di invio massimo per connessione, &lt;n&gt;*1000 byte (default: 10000)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="44"/>
        <source>Use Universal Plug and Play to map the listening port (default: 1)</source>
        <translation>Usa Universal Plug and Play per mappare le porte in ascolto (default: 1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="45"/>
        <source>Use Universal Plug and Play to map the listening port (default: 0)</source>
        <translation>Usa Universal Plug and Play per mappare le porte in ascolto (default: 1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="46"/>
        <source>Fee per KB to add to transactions you send</source>
        <translation>Tariffa per KB da aggiungere alle transazioni inviate</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="47"/>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accetta da linea di comando e da comandi JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="48"/>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Esegui in background come demone e accetta i comandi
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="49"/>
        <source>Use the test network</source>
        <translation>Utilizza la rete di prova
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="50"/>
        <source>Output extra debugging information</source>
        <translation>Produci informazioni extra utili al debug</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="51"/>
        <source>Prepend debug output with timestamp</source>
        <translation>Anteponi all&apos;output di debug una marca temporale</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="52"/>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Invia le informazioni di trace/debug alla console invece che al file debug.log</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="53"/>
        <source>Send trace/debug info to debugger</source>
        <translation>Invia le informazioni di trace/debug al debugger</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="54"/>
        <source>Username for JSON-RPC connections</source>
        <translation>Nome utente per connessioni JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="55"/>
        <source>Password for JSON-RPC connections</source>
        <translation>Password per connessioni JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="56"/>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: 8421)</source>
        <translation>Attendi le connessioni JSON-RPC su &lt;porta&gt; (default: 8332)
 {8421)?}</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="57"/>
        <source>Allow JSON-RPC connections from specified IP address</source>
        <translation>Consenti connessioni JSON-RPC dall&apos;indirizzo IP specificato
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="58"/>
        <source>Send commands to node running on &lt;ip&gt; (default: 127.0.0.1)</source>
        <translation>Inviare comandi al nodo in esecuzione su &lt;ip&gt; (default: 127.0.0.1)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="59"/>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Esegui comando quando il blocco migliore cambia (%s in cmd è rimpiazzato dall&apos;hash del blocco)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="62"/>
        <source>Upgrade wallet to latest format</source>
        <translation>Aggiorna il portafoglio all&apos;ultimo formato</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="63"/>
        <source>Set key pool size to &lt;n&gt; (default: 100)</source>
        <translation>Impostare la quantità di chiavi di riserva a &lt;n&gt; (default: 100)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="64"/>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Ripeti analisi della catena dei blocchi per cercare le transazioni mancanti dal portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="65"/>
        <source>How many blocks to check at startup (default: 2500, 0 = all)</source>
        <translation>Quanti blocchi controllare all&apos;avvio (default: 2500, 0 = all)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="66"/>
        <source>How thorough the block verification is (0-6, default: 1)</source>
        <translation>Quant&apos;è accurata la verifica del blocco (0-6, default: 1)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="67"/>
        <source>
SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>Opzioni SSL: (leggi la Wiki Bitcoin per le istruzioni di setup SSL)</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="70"/>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>Utilizzare OpenSSL (https) per le connessioni  JSON-RPC
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="71"/>
        <source>Server certificate file (default: server.cert)</source>
        <translation>File certificato del server (default: server.cert)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="72"/>
        <source>Server private key (default: server.pem)</source>
        <translation>Chiave privata del server (default: server.pem)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="73"/>
        <source>Acceptable ciphers (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)</source>
        <translation>Cifrari accettabili (default: TLSv1+HIGH:!SSLv2:!aNULL:!eNULL:!AH:!3DES:@STRENGTH)
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="76"/>
        <source>This help message</source>
        <translation>Questo messaggio di aiuto
</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="77"/>
        <source>Usage</source>
        <translation>Utilizzo</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="78"/>
        <source>Cannot obtain a lock on data directory %s.  421 is probably already running.</source>
        <translation>Non è possibile ottenere il lock sulla directory dati %s. 421 è probabilmente già in funzione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="81"/>
        <source>421</source>
        <translation>421</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="88"/>
        <source>Error loading wallet.dat: Wallet requires newer version of 421</source>
        <translation>Errore caricamento wallet.dat. Il portafoglio richiede una nuova versione di 421</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="89"/>
        <source>Wallet needed to be rewritten: restart 421 to complete</source>
        <translation>Il portafoglio deve essere riscritto: riavvia 421 per completare</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="103"/>
        <source>%s, you must set a rpcpassword in the configuration file:
 %s
It is recommended you use the following random password:
rpcuser=peercoinrpc
rpcpassword=%s
(you do not need to remember this password)
If the file does not exist, create it with owner-readable-only file permissions.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="119"/>
        <source>Warning: Please check that your computer&apos;s date and time are correct.  If your clock is wrong 421 will not work properly.</source>
        <translation>Attenzione: Per favore controlla che la data e l&apos;orario del tuo computer sono corretti. Se il tuo orario è sbagliato 421 non funzionerà correttamente.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="82"/>
        <source>Loading addresses...</source>
        <translation>Caricamento indirizzi...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="83"/>
        <source>Error loading addr.dat</source>
        <translation>Errore caricamento addr.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="84"/>
        <source>Loading block index...</source>
        <translation>Caricamento dell&apos;indice del blocco...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="85"/>
        <source>Error loading blkindex.dat</source>
        <translation>Errore caricamento blkindex.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="86"/>
        <source>Loading wallet...</source>
        <translation>Caricamento portafoglio...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="87"/>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Errore caricamento wallet.dat: Portafoglio corrotto</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="90"/>
        <source>Error loading wallet.dat</source>
        <translation>Errore caricamento wallet.dat</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="91"/>
        <source>Cannot downgrade wallet</source>
        <translation>Impossibile effettuare il downgrade del portafoglio</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="92"/>
        <source>Cannot initialize keypool</source>
        <translation>Impossibile inizializzare il keypool</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="93"/>
        <source>Cannot write default address</source>
        <translation>Impossibile scrivere l&apos;indirizzo predefinito</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="94"/>
        <source>Rescanning...</source>
        <translation>Ripetere la scansione...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="95"/>
        <source>Done loading</source>
        <translation>Caricamento completato</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="96"/>
        <source>Invalid -proxy address</source>
        <translation>Indirizzo -proxy non valido</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="97"/>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;</source>
        <translation>Importo non valido per -paytxfee=&lt;amount&gt;</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="98"/>
        <source>Warning: -paytxfee is set very high.  This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Attenzione: -paytxfee è molto alta. Questa è la commissione che si paga quando si invia una transazione.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="101"/>
        <source>Error: CreateThread(StartNode) failed</source>
        <translation>Errore: CreateThread(StartNode) non riuscito</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="102"/>
        <source>To use the %s option</source>
        <translation>Per usare l&apos;opzione %s</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="112"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="113"/>
        <source>An error occured while setting up the RPC port %i for listening: %s</source>
        <translation>Errore durante il settaggio della porta RPC %i per l&apos;ascolto: %s</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="114"/>
        <source>You must set rpcpassword=&lt;password&gt; in the configuration file:
%s
If the file does not exist, create it with owner-readable-only file permissions.</source>
        <translation>Devi impostare nel file di configurazione rpcpassword=&lt;password&gt;:
%s
Se il file non esiste, crealo con permesso sola lettura del proprietario. </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="122"/>
        <source>Error: Wallet locked, unable to create transaction  </source>
        <translation>Errore: Portafoglio bloccato, impossibile creare la transazione</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="123"/>
        <source>Error: This transaction requires a transaction fee of at least %s because of its amount, complexity, or use of recently received funds  </source>
        <translation>Errore: Questa transazione richiede una tariffa di almento %s a causa dell&apos;ammontare, complessità, o utilizzo di fondi ricevuti di recente</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="126"/>
        <source>Error: Transaction creation failed  </source>
        <translation>Errore: creazione della transazione fallita </translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="127"/>
        <source>Sending...</source>
        <translation>Invio...</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="128"/>
        <source>Error: The transaction was rejected.  This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Errore: la transazione è stata rifiutata. Ciò accade se alcune monete nel portafoglio sono state già spese, ad esempio se è stata usata una copia del file wallet.dat e i peercoin sono stati spesi dalla copia ma non segnati come spesi qui.</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="132"/>
        <source>Invalid amount</source>
        <translation>Importo non valido</translation>
    </message>
    <message>
        <location filename="../bitcoinstrings.cpp" line="133"/>
        <source>Insufficient funds</source>
        <translation>Fondi insufficienti</translation>
    </message>
</context>
</TS>
