FlappyCoin 
================================
Current version: 3.2

DOMAIN: http://flappycoin.biz

EXPLORER: http://explorer.flappycoin.biz


![FlappyCoin](http://flappycoin.biz/flap.nsf/flapcoin_med.png)

Copyright (c) 2014 Bitcoin Developers

Copyright (c) 2014 FlappyCoin Developers


Specifications:
---------------
Algorithm: Scrypt

Max number of coins 70,000,000,000 FLAP in circulation after 3 years

Block Time: 60 Seconds

Difficulty Retarget Time: 1 minutes (with KGW)

Premine: None


Rewards:
---------------
Block 1-110,000: 0-1,000,000 Reward

Block 110,001 — 140,000: 0-100,000 Reward

Block 140,001 — 140,500: 0-1,000,000 Reward

Block 140,501 — 200,000: 100,000 Reward

Block 200,001 — 300,000: 50,000 Reward

Block 300,001 — 400,000: 25,000 Reward

Block 400,001 — 500,000: 12,500 Reward

Block 500,001 - 600,000: 6,250 Reward

Block 600,000+: 50 + Transaction Fees Reward


Download Links:
----------------

http://flappycoin.biz

License
-------

Flappycoin is released under the terms of the MIT license. See `COPYING` for more
information or see http://opensource.org/licenses/MIT.
